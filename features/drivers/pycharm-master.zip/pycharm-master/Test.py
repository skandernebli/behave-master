from selenium import webdriver
driver=webdriver.Chrome("c:/driver/chromedriver.exe")
print("Tne chrome browser is starting")
driver.get("http://www.google.com")
print("The page browser is loaded successfully")
driver=webdriver.Firefox(executable_path="c:/driver/geckodriver.exe")
print("the firefox browser is starting")
driver.get("http://www.youtube.com")
print("The Firefox page browser is loaded successfully")
