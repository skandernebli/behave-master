import os
direct=os.getcwd()
print(direct)