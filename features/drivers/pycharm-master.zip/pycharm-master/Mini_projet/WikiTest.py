import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


class MyWikiTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome("c:/driver/chromedriver.exe")
    def test_WikiTest(self):
        driver=self.driver
        driver.maximize_window()
        driver.get("https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal")
        driver.find_element_by_name("search").send_keys("selenium",Keys.ENTER)

    def tearDown(self):
        driver=self.driver
        driver.quit()


if __name__ == '__main__':
    unittest.main()

