import os
import unittest

from HTMLTestRunner import HTMLTestRunner

import GoogleTest
import WikiTest
import LoginTest

direct = os.getcwd()


class MyTestSuite(unittest.TestCase):
    def test_issue(self):
        smoke_test = unittest.TestSuite()
        smoke_test.addTests([unittest.defaultTestLoader.loadTestsFromTestCase(GoogleTest.MyGoogleTest),
                             unittest.defaultTestLoader.loadTestsFromTestCase(WikiTest.MyWikiTest),
                             unittest.defaultTestLoader.loadTestsFromTestCase(LoginTest.MyLoginTest),
                             ])
        outfile = open(direct + "\smoketest.html", "w")
        runner = HTMLTestRunner.HTMLTestRunner(
            stream=outfile,
            title="TestCase Report",
            description="Smoke test"
        )
        runner.run(smoke_test)


if __name__ == '__main__':
    unittest.main()
