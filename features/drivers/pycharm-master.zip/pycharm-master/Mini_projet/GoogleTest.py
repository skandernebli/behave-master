import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys


class MyGoogleTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome("c:/driver/chromedriver.exe")
    def test_GoogleTest(self):
        driver=self.driver
        driver.maximize_window()
        driver.get("https://www.youtube.com/")
        driver.find_element_by_name("search_query").send_keys("songs 2021",Keys.ENTER)

    def tearDown(self):
        driver=self.driver
        driver.quit()


if __name__ == '__main__':
    unittest.main()
