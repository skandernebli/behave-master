import os
import unittest
from selenium import webdriver
from openpyxl import load_workbook

dir=os.getcwd()

class MyLoginTest(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome(dir+"\FilesDirectory\chromedriver.exe")
    def test_Login(self):
        driver=self.driver
        driver.maximize_window()
        driver.get("http://uitestingplayground.com")
        driver.find_element_by_link_text("Sample App").click()
        filepath = dir+"\FilesDirectory\Testcase.xlsx"  # Specification du path du fichier Excel : Testcase.xlsx.
        fichier = load_workbook(filepath)               # Chargement du fichier Excel.
        sheet = fichier.active                          # Sélection de la feuille active "Data".
        for i in range(2, 10):
            user = sheet.cell(row=i, column=1)          # Sélection de la cellule (i,1) avec i indice de la ligne et la colonne 1.
            pwd = sheet.cell(row=i, column=2)           # Sélection de la cellule (i,2) avec i indice de la ligne et la colonne 2.
            if user.value != None:                      # Test du contenu de la cellule user.
                driver.find_element_by_name("UserName").send_keys(user.value)
            if pwd.value != None:                       # Test du contenu de la cellule pwd.
                driver.find_element_by_name("Password").send_keys(pwd.value)
            driver.find_element_by_id("login").click()
            msg = driver.find_element_by_id("loginstatus").text
            bouton = driver.find_element_by_id("login").text
            if bouton == "Log Out":                     # Test du text du bouton dans le cas d'un login réussi.
                driver.find_element_by_id("login").click()
            sheet.cell(row=i, column=4).value = msg     # Ecriture du message msg dans la cellule (i,4) avec i indice de la ligne et la colonne 4.
            print(i, user.value, pwd.value, msg)
            fichier.save(filepath)                      # Sauvegarde du fichier excel pour confirmer l'écriture des messages.
    def tearDown(self):
        driver=self.driver
        driver.quit()


if __name__ == '__main__':
    unittest.main()