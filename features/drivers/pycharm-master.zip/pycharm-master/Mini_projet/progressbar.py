from selenium import webdriver
driver=webdriver.Chrome("c:/driver/chromedriver.exe")
driver.get("http://uitestingplayground.com/progressbar")
driver.find_element_by_id("startButton").click()
p=0
while p <75 :
    p = driver.find_element_by_id("progressBar").get_attribute("aria-valuenow")
    p=int(p)
driver.find_element_by_id("stopButton").click()
