from selenium import webdriver
from selenium.webdriver.support.select import Select

driver=webdriver.Chrome("c:/driver/chromedriver.exe")
driver.get("http://nxtgenaiacademy.com/demo-site/")
driver.find_element_by_name("vfb-5").send_keys("Maamoun")
driver.find_element_by_name("vfb-7").send_keys("Krifa")
driver.find_element_by_class_name("vfb-choice").click()
driver.find_element_by_id("vfb-13-address").send_keys("2 rue El Amine")
driver.find_element_by_id("vfb-13-city").send_keys("Sousse")
driver.find_element_by_id("vfb-13-state").send_keys("TN")
driver.find_element_by_id("vfb-13-zip").send_keys("4002")
Select(driver.find_element_by_id("vfb-13-country")).select_by_value("Tunisia")
driver.find_element_by_id("vfb-14").send_keys("maamoun.krifa@hotmail.com")
driver.find_element_by_id("vfb-18").send_keys("09/29/2021")
Select(driver.find_element_by_id("vfb-16-hour")).select_by_value("05")
Select(driver.find_element_by_id("vfb-16-ampm")).select_by_value("PM")
Select(driver.find_element_by_id("vfb-16-min")).select_by_value("30")
driver.find_element_by_id("vfb-19").send_keys("21175172")
driver.find_element_by_id("vfb-20-0").click()
driver.find_element_by_id("vfb-23").send_keys("Testing")
driver.find_element_by_id("vfb-3").send_keys("45")

