import time

import time
from selenium import webdriver
driver=webdriver.Chrome("c:/driver/chromedriver.exe")
driver.get("http://uitestingplayground.com")
titre=driver.title
long=len(titre)
print(titre)
print(long)
driver.back()
driver.forward()
time.sleep(2)
driver.refresh()
driver.close()